<?php error_reporting(E_ERROR|E_PARSE);
  include('../Connections/job.php');
   session_start();
  
  // $user_check = $_SESSION['Email'];
   
  // $ses_sql = mysqli_query($conn,"select * from admintb where userid = '$user_check' ");
   
   //$row = mysqli_fetch_array($ses_sql,MYSQLI_NUM);
   
   //$login_session = $row[1];

  if(!isset($_SESSION['ID'])){
  	// echo $_SESSION['Email'];
      header("location:../index.php");
   }
?>