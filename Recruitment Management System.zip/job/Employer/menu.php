<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Profile.php">Profile<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="ManageJob.php">Manage Job<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="ManageWalkin.php">Manage Walkin<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Application.php">Application<span class="tab-l"></span><span class="tab-r"></span></a></li>
                
                <li><a href="logout1.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->